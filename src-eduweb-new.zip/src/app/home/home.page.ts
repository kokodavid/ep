import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { Platform, NavController, AlertController } from '@ionic/angular';
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
  data: any;
  assets: any;
  student: any;
  school: any;
  constructor(private route: ActivatedRoute, private router: Router, private navCtrl: NavController) {
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.data = this.router.getCurrentNavigation().extras.state.details;
        if (this.data === null || this.data === undefined ) {
          this.navCtrl.navigateRoot('/dashboard');
        } else {
        this.school = this.data.school;
        // console.log(this.data, this.school);
        this.assets = `https://${this.school}.eduweb.co.ke/assets/students/`;
        }
      }
    });
  }
  ngOnInit() {

  }
  posts(student) {
    // console.log(student);
    const navigationExtras: NavigationExtras = {
      state: {
        details: student,
      }
    };
    this.router.navigate(['blog'], navigationExtras);
  }
  details(student) {
    // console.log(student);
    const navigationExtras: NavigationExtras = {
      state: {
        details: student,
      }
    };
    this.router.navigate(['info'], navigationExtras);
  }
  fees(student) {
    // console.log(student);
    const navigationExtras: NavigationExtras = {
      state: {
        details: student,
      }
    };
    this.router.navigate(['fees'], navigationExtras);
  }
  grades(student) {
    // console.log(student);
    const navigationExtras: NavigationExtras = {
      state: {
        details: student,
      }
    };
    this.router.navigate(['grading'], navigationExtras);
  }
  albums(student) {
    // console.log(student);
    const navigationExtras: NavigationExtras = {
      state: {
        details: student,
      }
    };
    this.router.navigate(['gallery'], navigationExtras);
  }
}