import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import * as moment from 'moment';
import { MenuController, LoadingController } from '@ionic/angular';
import { SpinnerDialog } from '@ionic-native/spinner-dialog/ngx';
@Component({
  selector: 'app-list',
  templateUrl: 'list.page.html',
  styleUrls: ['list.page.scss']
})
export class ListPage implements OnInit {
  private selectedItem: any;
  data: any;
  school: any;
  public feedback: any;
  public feedbacks: any;
  public spin: any;
  loading: any;
  fake: any;
  public items: Array<{ title: string; note: string; icon: string }> = [];
  constructor(
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private spinnerDialog: SpinnerDialog,
    public loadingController: LoadingController) {
    this.spin = 0;
    this.fake = 0;
    setTimeout(() => {
      this.fake = 0;
    }, 3000);
    this.feedbacks = new Array();
    // this.route.queryParams.subscribe(params => {
    //   if (this.router.getCurrentNavigation().extras.state) {
    //     this.data = this.router.getCurrentNavigation().extras.state.details;

    //   }
    // });

    const user = localStorage.getItem('token');
    const u = JSON.parse(user);
    this.data = u;
    this.school = this.data.students[0].school;
    console.log(this.school);
  }

 async ngOnInit() {
    const user = await localStorage.getItem('token');
    const u = JSON.parse(user);
    this.data = u;
    this.school = this.data.students[0].school;
    console.log(this.school);
  }
  async ionViewWillEnter() {
    this.authService.presentLoading();
    /// this.spinnerDialog.show();
    // etTimeout(async () => await this.spinnerDialog.hide(), 3000);
    this.spin = 1;
    await this.authService.checkFeed().then(
        feed => {
        this.spin = 0;
        // console.log(feed);
        this.feedback = feed;
        }
      );

    await this.authService.news().subscribe(
          news => {
            this.spin = 0;
            this.authService.dismiss();
          // console.log(news);
            this.data = news;
            this.feedbacks = this.data.data.feedback[this.school];
            // console.log(this.feedbacks);
          }
        );
  }
  addfeed() {
     const navigationExtras: NavigationExtras = {};
     this.router.navigate(['feedback'], navigationExtras);
   }

  formatDate(date) {
    return moment(date).format('MMM D, YYYY');
  }
  // add back when alpha.4 is out
  // navigate(item) {
  //   this.router.navigate(['/list', JSON.stringify(item)]);
  // }
}
