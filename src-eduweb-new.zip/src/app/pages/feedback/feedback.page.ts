import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { EnvService } from '../../services/env.service';
import { DataService } from '../../services/data.service';
import { NgForm } from '@angular/forms';
import { AlertService } from 'src/app/services/alert.service';
import { AlertController, NavController, LoadingController } from '@ionic/angular';
@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.page.html',
  styleUrls: ['./feedback.page.scss'],
})
export class FeedbackPage implements OnInit {
data: any;
students: any;
response: any;
school: any;
fake: any;
  constructor(
     private alertService: AlertService,
     private dataService: DataService,
     private authService: AuthService,
     private navCtrl: NavController,
     ) {
      this.students = new Array();
      this.fake = 0;
      // setTimeout(() => {
      //   this.authService.dismiss();
      //   // this.fake = 0;
      // }, 2000);

      }

  ngOnInit() {
  }

  async ionViewWillEnter() {
    this.authService.presentLoading();
    await this.authService.getStudents().subscribe(
      news => {
        this.authService.dismiss();
        this.data = news;
        this.students = this.data.data.students;
        this.school = this.students[0].school;
        // console.log(this.students, this.school);
      }
    );
  }

  post(form: NgForm) {
    this.authService.presentLoading();
    // console.log(form.value);
    this.authService.addfeed(form.value.student, form.value.subject, form.value.message, this.school).subscribe(
      data => {
        this.response = data;
        if (this.response.response) {
          this.authService.dismiss();
          this.navCtrl.navigateRoot('/dashboard');
          this.alertService.presentToast(this.response.data);
        } else {
          this.alertService.presentToast('Error Occured while posting your feedback...');
        }
      },
      error => {
        this.authService.dismiss();
        // console.log(error);
      },
      () => {
      }
    );
  }

}
