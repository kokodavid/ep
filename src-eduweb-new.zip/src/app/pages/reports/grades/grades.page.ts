import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { isNgTemplate } from '@angular/compiler';
import * as moment from 'moment';
import { FileOpener } from '@ionic-native/file-opener/ngx';
// import { mkdir } from 'fs';
@Component({
  selector: 'app-grades',
  templateUrl: './grades.page.html',
  styleUrls: ['./grades.page.scss'],
})
export class GradesPage implements OnInit {
student: any;
reportCard: any;
assets: any;
reportdata: any;
types: any[];
subjects: any;
comments: any;
examTypes: any[];
marks: any;
public schoolInfo: any[];
schoolHeaders: any;
usehead: any;
header: any;
header1: any;
positions: any;
lastterm: any;
totals: any;
data: any;
keys: any[];
col1: any;
data1: any;
type: any[];
  constructor(
     private route: ActivatedRoute,
     private router: Router,
     private authService: AuthService,
     private fileOpener: FileOpener,) {
    this.subjects = new Array();
    this.comments = new Array();
    this.types = new Array();
    this.marks = new Array();
    this.examTypes = new Array();
    this.schoolInfo = new Array();
    this.type = new Array();
    this.lastterm =  new Object();
    this.positions = new Object();
    this.totals = new Object();
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.student = this.router.getCurrentNavigation().extras.state.details;
        this.reportCard = this.router.getCurrentNavigation().extras.state.reportcards;
        this.type = this.router.getCurrentNavigation().extras.state.examTypes;
        this.schoolInfo = this.router.getCurrentNavigation().extras.state.schoolInfo;
        this.assets = this.student.student_image === null ? 1 :
        `https://${this.student.school}.eduweb.co.ke/assets/students/${this.student.student_image}`;
        // console.log(this.reportCard);
        const data = this.reportCard.report_data;
        // console.log(this.student);
        this.reportdata = JSON.parse(data);
        this.subjects = this.reportdata.subjects;

        if (this.subjects) {
          this.subjects.map((item) => {
           // console.log(item.marks)
            item.marks = item.marks === undefined ? {} : item.marks;
            // console.log(item.marks)
            Object.keys(item.marks).map((examType) => {
              if (this.examTypes.indexOf(examType) === -1 ) {
                this.examTypes.push(examType);
              }
           });
          });
          this.type.forEach(el => {
            this.examTypes.forEach(e => {
              if (e === el.exam_type ) {
                this.types.push(e);
            }
            });
          });
        }

        this.col1 = this.examTypes.length;
        console.log(this.types);
        //onsole.log(this.col1, this.examTypes);
        this.positions = this.reportdata.position;
        this.totals = this.reportdata.totals;
        this.lastterm = this.reportdata.position_last_term === false ? {} : this.reportdata.position_last_term;
        // console.log(this.reportdata, this.examTypes);
        this.comments = this.reportdata.comments;
        //console.log(this.subjects, this.marks);
        // get headers
        const schoolDetails = {};
        this.schoolInfo.forEach(element => {
          if (element.name === 'Letterhead') {
              if (
              element.name === 'Letterhead'
              || element.name === 'logo'
              || element.name === 'School Name'
              || element.name === 'Address 2'
              || element.name === 'Address 1'
              || element.name === 'Phone Number'
              || element.name === 'Email Address'
              || element.name === 'Phone Number 2'
              ) {
            // console.log(element.name, element.value);
            if (element.name === 'Letterhead') {
              const Letterhead = element.value;
              schoolDetails['head'] = Letterhead;
            } else if (element.name === 'logo') {
              const Logo = element.value;
              schoolDetails['Logo'] = Logo;
            } else if (element.name === 'School Name') {
              const schoolname = element.value;
              schoolDetails['schoolname'] = schoolname;
            } else if (element.name === 'Address 2') {
              schoolDetails['address2'] = element.value;
            } else if (element.name === 'Address 1') {
              schoolDetails['address1'] = element.value;
            } else if (element.name === 'Phone Number') {
              schoolDetails['phone'] = element.value;
            } else if (element.name === 'Phone Number 2') {
              schoolDetails['phone2'] = element.value;
            } else if (element.name === 'Email Address') {
              schoolDetails['email'] = element.value;
            }
            } else {
         }
        }
      });
        this.schoolHeaders = schoolDetails;
        this.usehead = this.schoolHeaders.head ? 1 : 0;
        this.header = `https://${this.student.school}.eduweb.co.ke/assets/schools/${this.schoolHeaders.head}`;
        this.header1 = `https://${this.student.school}.eduweb.co.ke/assets/schools/${this.schoolHeaders.head}`;
        // console.log(this.header, this.header1);
    }
    });

}

  ngOnInit() {
  }
  async ionViewWillEnter() {

    await this.authService.keys(this.student.school).subscribe(
      k => {
        //console.log(k);
        this.data = k;
        this.keys = this.data.data;
        //console.log(this.keys);
      }
    );

    
  }
  getMIMEtype(extn) {
    let ext = extn.toLowerCase();
    let MIMETypes = {
      'txt' :'text/plain',
      'docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'doc' : 'application/msword',
      'pdf' : 'application/pdf',
      'jpg' : 'image/jpeg',
      'bmp' : 'image/bmp',
      'png' : 'image/png',
      'xls' : 'application/vnd.ms-excel',
      'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'rtf' : 'application/rtf',
      'ppt' : 'application/vnd.ms-powerpoint',
      'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
    };
    return MIMETypes[ext];
  }
  open(file) {
   const  fileExtn = file.split('.').reverse()[0];
   const fileMIMEType = this.getMIMEtype(fileExtn);
   console.log(fileExtn, fileMIMEType, file);
   this.fileOpener.showOpenWithDialog(file, fileMIMEType)
                .then(() => console.log('File is opened'))
                .catch(e => console.log('Error openening file', e));

  }
  formatDate(date) {
    return moment(date).format('MMM D, YYYY');
  }
  format(value) {
   // console.log(value);
    // console.log(value.grade);

  }
}
