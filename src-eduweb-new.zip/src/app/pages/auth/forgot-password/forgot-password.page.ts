import { Component, OnInit } from '@angular/core';
import { ModalController, NavController, MenuController, AlertController } from '@ionic/angular';
import { NgForm } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { AlertService } from 'src/app/services/alert.service';
import { Keyboard } from '@ionic-native/keyboard/ngx';
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.page.html',
  styleUrls: ['./forgot-password.page.scss'],
})
export class ForgotPasswordPage implements OnInit {
  code: any;
  data: any;
  masks: any;
  phone: any;
  value: any;
  constructor(
    //private keyboard: Keyboard,
    private modalController: ModalController,
    private authService: AuthService,
    private navCtrl: NavController,
    private alertCtrl: AlertController,
    private alertService: AlertService,
    private menu: MenuController) {
      this.value = 0;
      this.menu.enable(false);
      this.code = 0;
  }

  ngOnInit() {

  }
  check(form: NgForm) {
    const x = form.value.phone;
    const ph = x.toString().replace(/\s/g, '');
    this.authService.checkforgot(ph).subscribe(data => {
      this.data = data;
      console.log(this.data.response);
      if (this.data.response === 'Success') {
         this.code = 1;
         this.phone = form.value.phone;
      } else if (this.data.response === 'error') {
       // this.errmsg('Error occured while trying to reset your password  please try again later...');
      }
      },
      error => {
        // this.errmsg('Error occured while trying to reset your password  please try again later...');
        // console.log(error);
      },
    );
  }
  async errmsg(info) {
    const alert = await this.alertCtrl.create({
      message: info,
      subHeader: 'Info',
      buttons: ['Ok']
     });
    await alert.present();
  }
  runTimeChange(x) {
    // const e = this.value;
    let e = x.target.value;
    console.log(e.length);
    if (e.length === 4 || e.length === 8) {
    this.value = e + ' ';
    console.log(this.value);
    } else {
      this.value = this.value;
    }
 }
  verify(form: NgForm) {
    const x = this.phone;
    const ph = x.toString().replace(/\s/g, '');
    this.authService.verifypassword(form.value.code, ph).subscribe(data => {
      this.data = data;
      if (this.data.response === 'Success') {
        console.log(form.value);
        this.authService.login(ph, form.value.code).subscribe( res => {
          // console.log(data);
          this.data = res;
          if (this.data.response === 'success') {
            // this.alertService.presentToast('Loggedin  Successfully');
            if (ph) {
            const creds = {
              username: ph,
              password: form.value.code,
            };
            localStorage.setItem('credentials', JSON.stringify(creds));
            this.dismissRegister();
          }
          } else {
            this.dismissRegister();
          }
          },
          error => {
            console.log(error);
          },
          () => {
            this.navCtrl.navigateRoot('/dashboard');
          }
        );

      }
      },
      error => {
        // this.dismissLogin();
        console.log(error);
      },
    );
  }
  register(form: NgForm) {
    if (form.value.pass === form.value.repass) {
    this.authService.registerPwd(form.value.pass, this.phone).subscribe(data => {
      this.data = data;
      if (this.data.response === 'sucesss') {
        this.dismissRegister();
         // this.code = 2;
         // this.phone = form.value.phone;
      } else {}
      },
      error => {
        // this.dismissLogin();
        console.log(error);
      },
      // () => {
      //   //this.dismissLogin();
      //   this.navCtrl.navigateRoot('/dashboard');
      // }
    );
    } else {

    }
  }
  numberWithSpaces(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}
  dismissRegister() {
    this.modalController.dismiss();
  }
}
