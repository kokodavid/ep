import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { Platform, NavController, AlertController } from '@ionic/angular';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { SpinnerDialog } from '@ionic-native/spinner-dialog/ngx';
import * as moment from 'moment';
@Component({
  selector: 'app-news',
  templateUrl: './news.page.html',
  styleUrls: ['./news.page.scss'],
})
export class NewsPage implements OnInit {
newsinfo: any;
attachments: any;
school: any;
assets: any;
downloadFile: any;
private fileTransfer: FileTransferObject;

  constructor(
    private transfer: FileTransfer,
    private spinnerDialog: SpinnerDialog,
    private file: File,
    private fileOpener: FileOpener,
    private navCtrl: NavController,
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router) {
    this.newsinfo = new Object();
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.newsinfo = this.router.getCurrentNavigation().extras.state.details;
        this.school = this.router.getCurrentNavigation().extras.state.school;
        if (this.newsinfo === null || this.newsinfo === undefined ) {
          this.navCtrl.navigateRoot('/dashboard');
        } else {
        console.log(this.newsinfo);
        const filename = this.newsinfo.attachment ? this.newsinfo.attachment : null ;
        const files = filename === null ? '' :  filename;
        const name = files; // .replace(/ /g, '%20');
        const nameArr = name === null ? null : name.split(',');
        this.attachments = nameArr[0] !== '' ? nameArr : [];
        console.log(this.newsinfo);
        this.assets = `https://${this.school}.eduweb.co.ke/assets/posts/`;
      }
      }
    });
  }

  ngOnInit() {
  }

  getMIMEtype(extn) {
    let ext = extn.toLowerCase();
    let MIMETypes={
      'txt' :'text/plain',
      'docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'doc' : 'application/msword',
      'pdf' : 'application/pdf',
      'jpg' : 'image/jpeg',
      'bmp' : 'image/bmp',
      'png' : 'image/png',
      'xls' : 'application/vnd.ms-excel',
      'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'rtf' : 'application/rtf',
      'ppt' : 'application/vnd.ms-powerpoint',
      'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
    }
    return MIMETypes[ext];
  }
  open(file) {
   this.authService.dismiss();
   // this.spinnerDialog.hide();
   const  fileExtn = file.split('.').reverse()[0];
   const fileMIMEType = this.getMIMEtype(fileExtn);
   console.log(fileExtn, fileMIMEType, file);
   this.fileOpener.showOpenWithDialog(file, fileMIMEType)
                .then(() => console.log('File is opened'))
                .catch(e => console.log('Error openening file', e));
  }
  async download(fileName, filePath) {
    await this.authService.presentLoading();
    // this.spinnerDialog.show();
    // const  fileExtn = fileName.split('.').reverse()[0];
    // const fileMIMEType = this.getMIMEtype(fileExtn);
    const url = encodeURI(filePath);
    this.fileTransfer = this.transfer.create();
    this.fileTransfer.download(url, this.file.dataDirectory + fileName, true).then((entry) => {
      // here logging our success downloaded file path in mobile.
      console.log('download completed: ' + entry.toURL());
      // open downloaded file
      // this.downloadFile = entry.toURL();
      this.open(entry.toURL());
    }).catch((error) => {
      this.authService.dismiss();
      // this.spinnerDialog.hide();
      // here logging an error.
      console.log('download failed: ' + JSON.stringify(error));
    });
  }

    openFileHandler() {
      this.fileOpener.open(this.downloadFile, '')
        .then(() => console.log('File is opened'))
        .catch(e => console.log('Error opening file', e));
    }
  trunc(text) {
    return text.length > 20 ? `${text.substr(0, 20)}...` : text;
  }
  /// format date
  formatdate(date) {
    console.log(date);
    return moment(date).format('DD MMMM YYYY');
  }
}
