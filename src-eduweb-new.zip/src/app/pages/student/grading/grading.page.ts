import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser/ngx';
import * as moment from 'moment';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { SpinnerDialog } from '@ionic-native/spinner-dialog/ngx';
@Component({
  selector: 'app-grading',
  templateUrl: './grading.page.html',
  styleUrls: ['./grading.page.scss'],
})
export class GradingPage implements OnInit {
  data: any;
  data1: any;
  data2: any;
  reportcards: any;
  types: any[];
  student: any;
  school: any;
  segment: any;
  assets: any;
  term: any;
  data3: any;
  data4: any;
  assessments: any;
  exams: any;
  schoolInfo: any;
  data5: any;
  schoolDetails: any;
  schoolHeaders: any;
  reportdata: any;
  subjects: any;
  examTypes: any[];
  userinfo: any;
  feedback: any;
  students: any;
  examdata: any;
  type: any[];
  url: any;
  fake: any;
  private fileTransfer: FileTransferObject;
  options: InAppBrowserOptions = {
    location : 'yes', // Or 'no'
    hidden : 'no', // Or  'yes'
    clearcache : 'yes',
    clearsessioncache : 'yes',
    zoom : 'yes',// Android only ,shows browser zoom controls
    hardwareback : 'yes',
    mediaPlaybackRequiresUserAction : 'no',
    shouldPauseOnSuspend : 'no', // Android only
    closebuttoncaption : 'Close', // iOS only
    disallowoverscroll : 'no', // iOS only
    toolbar : 'yes', // iOS only
    enableViewportScale : 'no', // iOS only
    allowInlineMediaPlayback : 'no', // iOS only
    presentationstyle : 'pagesheet', // iOS only
    fullscreen : 'yes', // Windows only
};
  constructor(
     private transfer: FileTransfer,
     private spinnerDialog: SpinnerDialog,
     private file: File,
     private iab: InAppBrowser,
     private authService: AuthService,
     private route: ActivatedRoute,
     private fileOpener: FileOpener,
     private router: Router) {
    this.reportcards = new Array();
    this.exams = new Array();
    this.assessments = new Array();
    this.schoolInfo = new Array();
    this.examdata = new Array();
    this.term = new Object();
    this.types = new Array();
    this.type = new Array();
    this.fake = 1;
    setTimeout(() => {
      this.fake = 0;
    }, 3000);
    // this.getSesion();
    this.schoolDetails = new Object();
    this.examTypes = new Array();
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.student = this.router.getCurrentNavigation().extras.state.details;
        this.assets = this.student.student_image === null ? 1 :
        `https://${this.student.school}.eduweb.co.ke/assets/students/${this.student.student_image}`;
        this.url =  `https://${this.student.school}.eduweb.co.ke/assets/students/`;
      }
    });
    console.log(this.student);
    this.segment = 'reports';
    // this.schoolHeader();
    // console.log(this.schoolHeaders);
    const data = this.reportcards.report_data === undefined ? [] : this.reportcards.report_data;
    // console.log(this.reportdata.subjects);
   // console.log(data);
    this.reportdata = data.length === 0 ? data : JSON.parse(data);
    this.subjects = data.length === 0 ? data : this.reportdata.subjects;
    // console.log(this.subjects);
    if (this.subjects) {
      this.subjects.map((item) => {
        // console.log(item.marks)
        item.marks = item.marks === undefined ? {} : item.marks;
        // console.log(item.marks);
        Object.keys(item.marks).map((examType) => {
          if (this.examTypes.indexOf(examType) === -1 ) {
            this.examTypes.push(examType);
          }
        });
      });
    }
    // console.log(this.examTypes);
  }

  ngOnInit() {
  }


  async ionViewWillEnter() {
    await this.authService.checkFeed().then(
      feed => {
       console.log(feed);
       this.feedback = feed;
      }
    );
    await this.authService.cards(this.student.school, this.student.student_id).subscribe(
      reportcards => {
        this.data = reportcards;
       // console.log(reportcards);
        if (this.data.nodata) {
          this.reportcards = [];
        } else {
        this.reportcards = this.data.data.reverse();
        // console.log(this.reportcards);
        }
      }
    );

    await this.authService.getSchool(this.student.school).subscribe(
      school => {
       // console.log(news);
        this.data5 = school;
        this.schoolInfo = this.data5.data;
        // console.log(this.schoolInfo);
      }
    );
    await this.authService.currentTerm(this.student.school).subscribe(
      terms => {
       // console.log(news);
        this.data2 = terms;
        this.term = this.data2.data;
        console.log(this.term);
      }
    );
    await this.authService.examsTypes(this.student.school, this.student.class_cat_id).subscribe(
      types => {
        // console.log(homeworks.data);
        this.data1 = types;
        if (this.data1.nodata) {
          this.types = [];

        } else {
        this.types = this.data1.data;
        }
        console.log(this.types);

      }
    );
  }

  getMIMEtype(extn) {
    let ext = extn.toLowerCase();
    let MIMETypes = {
      'txt' :'text/plain',
      'docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'doc' : 'application/msword',
      'pdf' : 'application/pdf',
      'jpg' : 'image/jpeg',
      'bmp' : 'image/bmp',
      'png' : 'image/png',
      'xls' : 'application/vnd.ms-excel',
      'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'rtf' : 'application/rtf',
      'ppt' : 'application/vnd.ms-powerpoint',
      'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
    }
    return MIMETypes[ext];
  }
  view(file) {
   this.authService.dismiss();
  //  this.spinnerDialog.hide();
   const  fileExtn = file.split('.').reverse()[0];
   const fileMIMEType = this.getMIMEtype(fileExtn);
   this.fileOpener.showOpenWithDialog(file, fileMIMEType)
                .then(() => console.log('File is opened'))
                .catch(e => console.log('Error openening file', e));
  // console.log(file);
  // this.fileOpener.showOpenWithDialog(file, 'application/*')
  // .then(() => console.log('File is opened'))
  // .catch(e => console.log('Error opening file', e));
  }
  segmentChanged(ev: any) {
    // console.log('Segment changed', ev);
    const value = ev.detail.value;
    if (value === 'exam') {
      this.fake = 1;
      setTimeout(() => {
        this.fake = 0;
      }, 2000);
      this.exam();
    }
    if (value === 'Assessment') {
      this.fake = 1;
      setTimeout(() => {
        this.fake = 0;
      }, 2000);
      this.assessment();
    }
  }
  view1(file) {
    // const browser = 
    // this.iab.create(file);
    let target = '_blank';
    this.iab.create(file, target, this.options);
    // browser.executeScript(...);
    // browser.insertCSS(...);
    // browser.on('loadstop').subscribe(event => {
    //   browser.insertCSS({ code: "body{color: #eee;" });
    // });

    // browser.close();
  }
  // public openWithSystemBrowser(url : string){
  //     let target = "_system";
  //     this.iab.create(url,target,this.options);
  // }
  // public openWithInAppBrowser(url : string){
  // }
  // public openWithCordovaBrowser(url : string){
  //     let target = "_self";
  //     this.iab.create(url,target,this.options);
  // }  
  async exam() {
    await this.authService.exams(this.student.school, this.student.class_id, this.student.student_id, this.term.term_id).subscribe(
      exams => {
        // console.log(homeworks.data);
        if (this.data.nodata) {
          this.exams = [];
        } else {
        this.data3 = exams;
        this.exams = this.data3.data === undefined ? [] : this.data3.data;
        // this.exams.sort((a, b) => (a.exam_type > b.exam_type) ? 1 : -1);
        this.exams.forEach(e => {
              this.type.push(e.exam_type);
        });
        // console.log(this.type);
        const myArray = this.type;
        this.types = myArray.filter((v, i, a) => a.indexOf(v) === i);
        // console.log(this.types);
        console.log(this.exams);
        this.types.forEach(el => {
          console.log(el);
          const ty = el;
          let x = [];
          for ( var i = 0; i < this.exams.length; i++) {
            if (this.exams[i].exam_type === el) {
            x.push(this.exams[i]);
            }
          }
          const data = {
            ty,
            marks: x,

          };
          this.examdata.push(data);
          console.log(data);
    });
   // console.log(this.examdata);
        }
      }
    );

  }
onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}
  async assessment() {
    await this.authService.assessment(this.student.school, this.student.student_id ).subscribe(
      assessments => {
        // console.log(homeworks.data);
        this.data4 = assessments;
        if (this.data4.nodata) {
          this.assessments = [];
        } else {
          const data1 = this.data4.data === undefined ? [] : this.data4.data;
          data1.sort((a, b) => (a.term_id < b.term_id) ? 1 : -1);
          const data = data1;
          this.assessments = data;
        }
        // console.log(this.assessment);

      }
    );
  }
  reportData(reports) {
    // console.log(this.student);
    const navigationExtras: NavigationExtras = {
      state: {
        details: this.student,
        reportcards: reports,
        examTypes: this.types,
        schoolInfo: this.schoolInfo,
      }
    };
    this.router.navigate(['grades'], navigationExtras);
  }
  async download(fileName, filePath) {
   // this.spinnerDialog.show();
    // const  fileExtn = fileName.split('.').reverse()[0];
    // const fileMIMEType = this.getMIMEtype(fileExtn);
    await this.authService.presentLoading();
    const url = encodeURI(filePath);
    this.fileTransfer = this.transfer.create();
    this.fileTransfer.download(url, this.file.dataDirectory + fileName, true).then((entry) => {
      // here logging our success downloaded file path in mobile.
      console.log('download completed: ' + entry.toURL());
      // open downloaded file
      // this.downloadFile = entry.toURL();
      this.view(entry.toURL());
    }).catch((error) => {
      this.authService.dismiss();
      // this.spinnerDialog.hide();
      // here logging an error.
      console.log('download failed: ' + JSON.stringify(error));
    });
  }
  addfeed() {
    const navigationExtras: NavigationExtras = {};
    this.router.navigate(['feedback'], navigationExtras);
  }

  format(date) {
    return moment(date).format('MMM D, YYYY');
  }

}
