import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import * as moment from 'moment';
@Component({
  selector: 'app-blog',
  templateUrl: './blog.page.html',
  styleUrls: ['./blog.page.scss'],
})
export class BlogPage implements OnInit {
  data: any;
  data1: any;
  posts: any[];
  homeworks: any;
  student: any;
  school: any;
  segment: any;
  assets: any;
  feedback: any;
  fake: any;
  constructor(private authService: AuthService, private route: ActivatedRoute, private router: Router) {
    this.segment = 'posts';
    this.posts = new Array();
    this.homeworks = new Array();
    this.fake = 1;
    setTimeout(() => {
      this.fake = 0;
    }, 3000);
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.student = this.router.getCurrentNavigation().extras.state.details;
        this.assets = this.student.student_image === null ? 1 :
        `https://${this.student.school}.eduweb.co.ke/assets/students/${this.student.student_image}`;
      }
    });
  }

  ngOnInit() {
  }
  async ionViewWillEnter() {
    await this.authService.checkFeed().then(
      feed => {
       console.log(feed);
       this.feedback = feed;
      }
    );
    await this.authService.posts(this.student.school, this.student.student_id, 1).subscribe(
      posts => {
       // console.log(news);
        this.data = posts;
        this.posts = this.data.data.posts === undefined ? [] : this.data.data.posts;
        console.log(this.posts);
      }
    );
    await this.authService.homeworks(this.student.school, this.student.student_id).subscribe(
      homeworks => {
        // console.log(homeworks.data);
        this.data1 = homeworks;
        this.homeworks = this.data1.data === undefined ? [] : this.data1.data;
        console.log(this.homeworks);

      }
    );
  }

formatDate(date) {
  return moment(date).format('MMM D, YYYY');
}

  segmentChanged(ev: any) {
    // console.log('Segment changed', ev);
  }
  addfeed() {
    const navigationExtras: NavigationExtras = {};
    this.router.navigate(['feedback'], navigationExtras);
  }
}
